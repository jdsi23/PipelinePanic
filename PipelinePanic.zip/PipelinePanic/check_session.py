from flask import session; print('Session contents:', session)
